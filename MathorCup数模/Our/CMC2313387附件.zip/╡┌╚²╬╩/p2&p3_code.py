import numpy as np
import pandas as pd
from random import random, uniform

import matplotlib.pyplot as plt

def create_max_load_matrix(data, max_loads):
 source_nodes = data["场地1"].unique()
 target_nodes = data["场地2"].unique()
 matrix = pd.DataFrame(columns=target_nodes, index=source_nodes).fillna(0)
 for idx, row in max_loads.iterrows():
  source, target = row["Route"].split("_")
  matrix.at[source, target] = row["货量"]
  matrix.at[target, source] = row["货量"]
 return matrix



# 根据输入数据创建初始分配矩阵
def create_initial_matrix(data):
 source_nodes = data["场地1"].unique()
 target_nodes = data["场地2"].unique()
 matrix = pd.DataFrame(columns=target_nodes, index=source_nodes).fillna(0)
 for idx, row in data.iterrows():
  matrix.at[row["场地1"], row["场地2"]] = row["货量"]
 return matrix



# 初始化粒子群
def initialize_particles(num_particles, matrix, mask_matrix):
 particles = []
 for _ in range(num_particles):
  particle_position = matrix.copy()
  for i in range(particle_position.shape[0]):
   for j in range(particle_position.shape[1]):
    if particle_position.iloc[i, j] != 0:
     particle_position.iloc[i, j] = particle_position.iloc[i, j] * uniform(0, 1)
     
  redistribute_goods(particle_position, matrix)
  particle_position = particle_position * mask_matrix
  particle_velocity = matrix.applymap(lambda x: uniform(-1, 1))
  particles.append({"position": particle_position, "velocity": particle_velocity, "best_position": particle_position.copy()})
 return particles




# 计算目标函数
def objective_function(position_matrix):
 # 定义系数
 c1 = 3
 c2 = 20
 c3 = 10000
 
 # 计算货量发生变化的线路数
 changed_lines = np.sum(position_matrix != initial_matrix)
 
 # 计算不能正常流转的货量
 stuck_goods = np.sum(position_matrix.iloc[:, 0])
 
 # 计算网络负荷情况
 target_loads = position_matrix.sum(axis=0)
 load_variance = np.var(target_loads) / max_load_variance
 
 # 计算目标函数值
 objective_value = c1 * changed_lines + c2 * stuck_goods + c3 * load_variance
 
 return objective_value

def redistribute_goods(new_position, initial_matrix):
 for i in range(new_position.shape[0]):
  for j in range(new_position.shape[1]):
   if new_position.iloc[i, j] == 0 and initial_matrix.iloc[i, j] != 0:
    remaining_goods = initial_matrix.iloc[i, j]
    non_zero_positions = np.where(new_position.iloc[i, :] != 0)[0]
    if len(non_zero_positions) > 0:
     redistribute_amount = int(remaining_goods / len(non_zero_positions))
     remaining_goods -= redistribute_amount * len(non_zero_positions)
     for k in non_zero_positions:
      new_position.iloc[i, k] += redistribute_amount
     new_position.iloc[i, j] = remaining_goods
     

# 粒子群优化算法
def particle_swarm_optimization(particles, num_iterations, inertia_weight, cognitive_coefficient, social_coefficient, mask_matrix):
 global_best_position = particles[0]["best_position"]
 global_best_value = objective_function(global_best_position)
 global_best_values = [global_best_value]  # 添加一个列表以存储每次迭代的全局最优解
 
 for _ in range(num_iterations):
  for particle in particles:
   position = particle["position"]
   velocity = particle["velocity"]
   best_position = particle["best_position"]
   
   # 更新速度
   r1, r2 = random(), random()
   cognitive_term = cognitive_coefficient * r1 * (best_position - position)
   social_term = social_coefficient * r2 * (global_best_position - position)
   new_velocity = inertia_weight * velocity + cognitive_term + social_term
   new_velocity = np.round(new_velocity * mask_matrix)
   particle["velocity"] = new_velocity
   
   # 更新位置
   new_position = position + new_velocity
   new_position = np.round(new_position * mask_matrix)
   redistribute_goods(new_position, initial_matrix)
   particle["position"] = new_position
   
   # 更新个体最优位置
   current_value = objective_function(new_position)
   if np.all(current_value < objective_function(best_position)):
    particle["best_position"] = new_position.copy()
    
   # 更新全局最优位置
   if np.all(current_value < global_best_value):
    global_best_position = new_position.copy()
    global_best_value = current_value
    
  global_best_values.append(global_best_value)  # 将当前迭代的全局最优解添加到列表中
  
 return global_best_position, global_best_value, global_best_values  # 返回全局最优解列表



# 读取Excel文件
file_path = "附件1：物流网络历史货量数据.xlsx"  # 请将此路径替换为您的Excel文件路径
df = pd.read_excel(file_path, engine="openpyxl")
# 将起点和终点的组合作为新的一列，注意需要对每一条线路的起点和终点进行排序
df['Route'] = df[['场地1', '场地2']].apply(lambda x: '_'.join(sorted(x)), axis=1)

# 按照线路进行分组，并计算历史最高货量
result = df.groupby('Route')['货量'].max().reset_index()

dc5_as_site1 = set()
dc5_as_site2 = set()

# 遍历表格数据
for _, row in df.iterrows():
 site1, site2 = row["场地1"], row["场地2"]
 if site1 == "DC5":
  dc5_as_site1.add(site2)
 if site2 == "DC5":
  dc5_as_site2.add(site1)
  
# 使用集合去除重复场地
unique_dc5_as_site1 = set(dc5_as_site1)
unique_dc5_as_site2 = set(dc5_as_site2)

print(f"DC5作为场地1与 {len(unique_dc5_as_site1)} 个场地2相连（去除重复）")
print(f"DC5作为场地2与 {len(unique_dc5_as_site2)} 个场地1相连（去除重复）")
print(unique_dc5_as_site1)



# 筛选出 DC5 作为场地 2 的数据
dc5_site2_data = df[df["场地2"] == "DC5"]

# 获取与 DC5 相连的其他场地
connected_sites = dc5_site2_data["场地1"].unique()

# 筛选出这些场地作为场地 1 的所有数据
data = df[df["场地1"].isin(connected_sites)]

# 去除与 DC5 相关的数据
data = data[data["场地2"] != "DC5"]

# 重置数据索引
data.reset_index(drop=True, inplace=True)

print(data)





# 创建初始矩阵
initial_matrix = create_initial_matrix(data)

# 修改后的掩蔽矩阵创建代码
mask_matrix = initial_matrix.copy()
mask_matrix[mask_matrix != 0] = 1
mask_matrix[mask_matrix == 0] = 0

# 算法参数
num_particles = 30
num_iterations = 100
inertia_weight = 0.7
cognitive_coefficient = 2
social_coefficient = 2

# 初始化粒子群
particles = initialize_particles(num_particles, initial_matrix, mask_matrix)

total_goods = initial_matrix.sum().sum()
max_load_variance = np.var(np.ones(initial_matrix.shape[1]) * total_goods / initial_matrix.shape[1])

# 执行粒子群优化算法
best_position, best_value, global_best_values = particle_swarm_optimization(particles, num_iterations, inertia_weight, cognitive_coefficient, social_coefficient, mask_matrix)
# 输出结果
print("最佳分配方案：\n", best_position)
print("最佳目标函数值：", best_value)

# 使用最佳分配方案计算货量发生变化的线路数、不能正常流转的货量及网络的负荷情况
changed_lines = np.sum(best_position != initial_matrix)
stuck_goods = np.sum(best_position.iloc[:, 0])
target_loads = best_position.sum(axis=0)
load_variance = np.var(target_loads)

print("货量发生变化的线路数：", changed_lines)
print("不能正常流转的货量：", stuck_goods)
print("网络负荷情况（方差）：", load_variance)

# 可视化结果
plt.plot(global_best_values)
plt.xlabel("Iteration")
plt.ylabel("Global Best Value")
plt.title("PSO Convergence")
plt.show()


# 计算每个目标场地的总货量
target_loads = best_position.sum(axis=0)

# 计算方差
load_variance = np.var(target_loads)

# 绘制负荷情况图
plt.figure(figsize=(10, 6))
plt.bar(target_loads.index, target_loads.values)
plt.axhline(y=target_loads.mean(), color='r', linestyle='--', label='Average Load')
plt.xlabel('Target Nodes')
plt.ylabel('Load')
plt.title(f'Load Distribution (Variance: {load_variance:.2f})')
plt.legend()
plt.show()